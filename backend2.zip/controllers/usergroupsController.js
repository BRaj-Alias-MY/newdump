let app = require('express');
let router = app.Router();
let usergroup = require('../models').user_groups;
let sequelize = require('../models').sequelize;
const Op = sequelize.Op;

router.get('/list',(req,res)=>{
	usergroup.findAll({
		attributes: ['id', 'groupName']
	}).then(usergroup => {
		res.send({'status':true,'data':usergroup});
	}).catch(err=>{
		res.send({'status':false,'message':'fail'});
	});
});

router.post('/',(req,res)=>{
	if(req.auth.access.addAccess){
		return usergroup.findOne({ where: {groupName : req.body.groupName} }).then(org => {
			if(org){
				res.send({'status' : false, "message" : 'Usergroup already exists.'});
			}else{
				//let user_data = req.body;
				//console.log(user_data);
				usergroup.afterCreate(function(model, options, done) {//hook1
					model.auth = req.auth ? req.auth.userId : 0;
				});
				usergroup.create({groupName:req.body.groupName,organizationId:req.auth.organization,userId:req.auth.userId}).then(result=>{
					res.send({'status' : true, 'message':'Success'});
				}).catch(err=>{
					console.log(err);
					res.send({"status":false,"message":"fail"});
				});

			}
		}).catch(err=>{
			console.log(err);
			res.send({"status":false,"message":"fail"});
		});
	}else{
		res.send({'status' : false, 'message':'Un Autherized.'});
	}
});


router.get('/',(req,res)=>{
	if(req.auth.access.gridAccess){
		usergroup.findAll({ where : {organizationId:req.auth.organization}}).then(result=>{
			res.send({"status":true,"data":result, access:req.auth.access});
		}).catch(err=>{
			res.send({'status' : false, 'message':'Fail'});
		});
	}else{
		res.send({'status' : false, 'message':'Un Autherized.', access:[req.auth.access]});
	}
});

router.get('/:id',(req,res)=>{
	if(req.auth.access.viewAccess && req.params.id){
		usergroup.findOne({ where : {organizationId:req.auth.organization,id:req.params.id}}).then(result=>{
			res.send({"status":true,"data":result});
		}).catch(err=>{
			res.send({'status' : false, 'message':'Fail'});
		});
	}else{
		req.params.id ? res.send({'status' : false, 'message':'Un Autherized.'}) : res.send({'status' : false, 'message':'No data found.'});
	}
});

router.post('/:id',(req,res)=>{
	if(req.auth.access.editAccess){
		usergroup.afterBulkUpdate(function(options) {//hook1
			options.auth = req.auth ? req.auth.userId : 0;
		});
		usergroup.update({groupName:req.body.groupname},{ where : {organizationId:req.auth.organization,id:req.params.id}}).then(result=>{
			res.send({'status' : true, 'message':'Success'});
		}).catch(err=>{
			console.log(err);
			res.send({"status":false,"message":"fail"});
		});

	}else{
		res.send({'status' : false, 'message':'Un Autherized.'});
	}
});

module.exports = router;