import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expert-dashboard',
  templateUrl: './expert-dashboard.component.html',
  styleUrls: ['./expert-dashboard.component.css']
})
export class ExpertDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
