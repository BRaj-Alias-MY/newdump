import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import Swal from 'sweetalert2/dist/sweetalert2.js'
import {UsersService} from '../services/users.service';
import { ValidationService } from '../../../services/validation.service';
import { GridOptions } from 'ag-grid-community';
import { ChildMessageRenderer } from '../../../childmessagerender.component';



@Component({
  selector: 'app-userdomainmap',
  templateUrl: './userdomainmap.component.html',
  styleUrls: ['./userdomainmap.component.css']
})
export class UserdomainmapComponent implements OnInit {
  update;
	items;
	lenght;
	btn_update = 'Update';
	btn_add = 'Add';
	access;
  IsForUpdate: boolean = false;
  btn_name

  constructor(private fb: FormBuilder, private route: Router, private api: UsersService) { }
  roles;
  domain;
  subdomain;
  selectedDevice;
  usergroups;
  organization;
  ngOnInit() {
    this.btn_name = 'Save';
    this.api.get_roles().subscribe(res=> this.roles = res.data);
    this.api.get_domain().subscribe(res=> this.domain = res.data);
    this.api.get_user_groups().subscribe(res=> this.usergroups = res.data);
    this.api.get_organization().subscribe(res=> this.organization = res.data);

   }

   userdomainForm = this.fb.group({
		id:[],
    fname: ['',ValidationService.alphaValidator],
    mname: ['',ValidationService.alphaValidator],
    lname: ['',ValidationService.alphaValidator],
    email: ['',ValidationService.emailValidator],
    phone: ['',ValidationService.numericValidator],
    gender: ['',ValidationService.alphaValidator],
    organization:[''],
    rolesID: [''],
    domainid: [''],
    subdomain: [''],
    usergroup: ['']
    });

    onChange($event) {
      this.api.get_subdomain(this.selectedDevice).subscribe(res=> this.subdomain = res.data);
      this.userdomainForm.patchValue({ subdomain: '' });
     }
     
    onSubmit(){
      console.log(this.userdomainForm.value);
      this.api.save_userdomain(this.userdomainForm.value).subscribe((res) => {
				if (res.status) {
					// this.grid();
          Swal.fire('Success..', 'Record insert/updated successfully.', 'success');
          this.userdomainForm.patchValue({ fname: '',mname: '',lname: '',email: '',phone: '',gender: '',organization: '',rolesID: '',domainid: '',subdomain: '',usergroup:'' });

					// this.clear_fields();
				} else {
					//this.loading.hide();
					Swal.fire('Oops...', 'Something went wrong!', 'error');
				}
			});
    }

}
