import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FileUploader, FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import { UsersService } from '../services/users.service';
import { ValidationService } from '../../../services/validation.service';
import { GridOptions } from 'ag-grid-community';
import { ChildMessageRenderer } from '../../../childmessagerender.component';

const URL = 'http://192.168.0.126:3000/api/userprofile/upload';

@Component({
	selector: 'app-userprofile',
	templateUrl: './userprofile.component.html',
	styleUrls: [ './userprofile.component.css' ]
})
export class UserprofileComponent implements OnInit {
	edu;
	exp;
	up_val: any;
	index = '';
	rpt_btn_name = '';
	update;
	items;
	btn_update = 'Update';
	btn_add = 'Add';
	private gridOptions: GridOptions;
	private gridApi;
	private gridColumnApi;

	private columnDefs;
	private rowData;
	private context;
	private frameworkComponents;

	selectedFile: File;

	public uploader: FileUploader = new FileUploader({
		url: URL,
		itemAlias: 'doc',
		headers: [ { name: 'authorization', value: localStorage.getItem('token') } ]
	});

	constructor(private fb: FormBuilder, private route: Router, private api: UsersService, private http: HttpClient) {
		// this.gridOptions = <GridOptions>{
		// 	paginationNumberFormatter: function(params) {
		// 		return '[' + params.value.toLocaleString() + ']';
		// 	}
		// };
		// this.columnDefs = [
		// 	{ headerName: 'Name', field: 'name' },
		// 	{ headerName: 'Type', field: 'type' },
		// 	{ headerName: 'URL', field: 'url' },
		// 	{ headerName: 'Email', field: 'email' },
		// 	{ headerName: 'ID', field: 'id', hide: true },
		// 	{
		// 		headerName: 'Action',
		// 		cellRenderer: 'childMessageRenderer',
		// 		colId: 'params',
		// 		value: 'id'
		// 	}
		// ];
		this.frameworkComponents = {
			childMessageRenderer: ChildMessageRenderer
		};
		this.context = { componentParent: this };
	}
	onEditClick(id) {
		console.log(id);
	}

	onGridReady(params) {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;

		params.api.sizeColumnsToFit();
	}

	methodFromParentEdit(cell, valls) {
		// Swal("Edit");
		console.log(valls.id);
		this.EditItem(valls.id);
	}

	methodFromParentView(cell, valls) {
		// Swal("View");
		console.log(valls);
		this.ViewItem(valls.id);
	}
	EditItem(item_id) {
		// console.log(item_id);
		this.sh_add = true;
		this.togel_name = 'Close';
		this.btn_name = 'Update';
		this.userprofileForm.patchValue(this.get_item_data_with_id(item_id));
		this.edu = this.get_item_data_with_id(item_id).organization_campuses;
		console.log(this.edu);
	}
	get_item_data_with_id(item_id) {
		for (let i = 0; i < this.grid_tab.length; i++) {
			if (this.grid_tab[i].id == item_id) {
				return this.grid_tab[i];
			}
		}
	}
	ngOnInit() {
		this.uploader.onAfterAddingFile = (file) => {
			file.withCredentials = false;
		};
		this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
			console.log('ImageUpload:uploaded:', item, status, response);
			alert('File uploaded successfully');
			this.btn_name = 'Save';
		};
		this.grid_tab = [];
		this.items = {
			about: '',
			address: '',
			pincode: '',
			linkedin: '',
			education: '',
			experiance: '',
			fileupload: ''
		};

		this.sh_add = false;
		this.togel_name = 'Add';
		this.edu = [];
		this.exp = [];
		this.btn_name = 'Save';
		this.view_item = [];
		this.current_page = 1;
		this.pages = [];
		this.start_record = 1;
		this.update = false;
		this.access = [];
		this.rpt_btn_name = this.btn_add;
		this.up_val = '';
		//this.grid();
	}

	userprofileForm = this.fb.group({
		id: [],
		about: [''],
		address: [''],
		zipcode: [''],
		linkedin: [''],
		education: [],
		experiance: [],
		resume: [''],
		edu:[],
		exp:[]
	});


	educationRepeat = this.fb.group({
		educationname: [ '' ],
		university: [ '' ],
		coursefrom: [ '' ],
		courseto: [ '' ],
		specialization: [ '' ],
		grade: [ '' ]
	});

	experianceRepeat = this.fb.group({
		organizationname: [ '' ],
		designation: [ '' ],
		joineddate: [ '' ],
		reliveddate: [ '' ]
	});

	access;
	IsForUpdate: boolean = false;
	newItem: any = {};
	updatedItem;
	btn_name: string;
	current_page: number;
	start_record: number;
	pages;
	total_records: number;
	grid_tab;
	sh_add: boolean;
	togel_name: string;
	view_item: any;

	addEducationdetails() {
		/*let iem = this.organizationRepeat.value;
    this.organization.push(iem); */
		if (this.rpt_btn_name == this.btn_add) {
			this.edu.push(this.educationRepeat.value);
		} else if (this.rpt_btn_name == this.btn_update) {
			this.edu[this.index] = this.educationRepeat.value;
		} else {
			//	Swal('Error in Form. Please try again later.');
		}
		this.clear_fields();
		this.rpt_btn_name = this.btn_add;
	}
	add_togel() {
		this.sh_add = this.sh_add ? false : true;
		this.togel_name = this.togel_name == 'Add' ? 'Close' : 'Add';
		this.btn_name = 'Save';
		this.userprofileForm.patchValue({ id: '', about: '' });
		this.edu = [];
	}
	paginate_fun(ppg) {
		this.current_page = ppg;
		//this.grid();
	}
	addExperiancedetails() {
		/*let iem = this.organizationRepeat.value;
    this.organization.push(iem); */
		if (this.rpt_btn_name == this.btn_add) {
			this.exp.push(this.experianceRepeat.value);
		} else if (this.rpt_btn_name == this.btn_update) {
			this.exp[this.index] = this.experianceRepeat.value;
		} else {
			//	Swal('Error in Form. Please try again later.');
		}
		this.clear_fields();
		this.rpt_btn_name = this.btn_add;
	}
	add_togel1() {
		this.sh_add = this.sh_add ? false : true;
		this.togel_name = this.togel_name == 'Add' ? 'Close' : 'Add';
		this.btn_name = 'Save';
		this.userprofileForm.patchValue({ id: '', about: '' });
		this.exp = [];
	}
	//paginate_fun(ppg) {
	//this.current_page = ppg;
	//this.grid();
	//}

	onSubmit() {
		this.userprofileForm.value.edu = this.edu 
		this.userprofileForm.value.exp = this.exp;
       if (this.userprofileForm.value.id > 0) {
			console.log(this.userprofileForm.value);
			this.api.userprofile_update(this.userprofileForm.value).subscribe((res) => {
				if (res.status) {
					this.userprofileForm.patchValue({ id: '', about: '' });
				} else {
					//this.loading.hide();
					//Swal('Oops...', 'Something went wrong!', 'error');
				}
			});
		} else {
			console.log(this.userprofileForm.value);
			this.api.add_userprofile(this.userprofileForm.value).subscribe((res) => {
				if (res.status) {
					this.userprofileForm.patchValue({ id: '', about: '' });
					//this.grid();
					//Swal('Success..', 'Record insert/updated successfully.', 'success');
					this.clear_fields();
					// this.clear_fields();
				} else {
					//this.loading.hide();
					//Swal('Oops...', 'Something went wrong!', 'error');
				}
			});  
		}
	}
	//grid() {
	//console.log(this.current_page);
	//this.api.get_organization_data().subscribe(data => {
	//this.access = data.access;
	//console.log(this.access);
	//if (this.access && this.access.gridAccess) {
	// console.log("Hello world");
	//this.grid_tab = data.data;
	//console.log(this.grid_tab);
	//this.pages = Array.apply(null, { length: this.access.total_pages }).map(Number.call, Number);
	//console.log(this.pages);
	//this.start_record = ((this.access.current_page - 1) * this.access.limit) + 1;
	//this.total_records = this.access.total_records;
	//}
	//this.sh_add = false;
	//this.togel_name = 'Add';
	//this.btn_name = 'Save';
	//this.loading.hide();
	//this.view_item = [];
	//});
	//}

	ViewItem(item_id) {
		this.view_item.push(this.get_item_data_with_id(item_id));
		console.log(this.view_item);
		this.sh_add = false;
		this.togel_name = 'Add';
	}

	back_view() {
		this.view_item = [];
	}
	// Edit Item
	EditCoverItem(profile, index) {
		this.index = index;
		this.educationRepeat.patchValue(profile);
		this.experianceRepeat.patchValue(profile);
		this.rpt_btn_name = this.btn_update;
	}

	clear_fields() {
		this.educationRepeat.patchValue({
			educationname: '',
			university: '',
			coursefrom: '',
			courseto: '',
			specialization: '',
			grade: ''
		});
		this.experianceRepeat.patchValue({
			organizationname: '',
			designation: '',
			joineddate: '',
			reliveddate: ''
		});
		this.userprofileForm.patchValue({
			about: "",
			address: "",
			zipcode: "",
			linkedin: "",
			education: "",
			experiance: "",
			resume:""
		});
		this.rpt_btn_name = this.btn_add;
	}
	/*  UpdateItem(id){
     console.log(id); */
	//var data = this.organizationForm.value;
	// data['cd_items_data']=this.organization_campuses;

	/*	this.api.get_update_organisation_data(id).subscribe(res => {
			if(res.status) {
				this.organizationForm.patchValue({id: '', name:'',email:''});

				}
		}); */
}

//}
